//   OpenNN: Open Neural Networks Library
//   www.opennn.net
//
//   P E R C E P T R O N   L A Y E R   3 D   C L A S S
//
//   Artificial Intelligence Techniques SL
//   artelnics@artelnics.com

#include "perceptron_layer_3d.h"
#include "tensors.h"
#include "strings_utilities.h"

namespace opennn
{

Dense3d::Dense3d(const Index& new_sequence_length,
                 const Index& new_input_dimension,
                 const Index& new_output_dimension,
                 const Dense3d::Activation& new_activation_function,
                 const string& new_name) : Layer()
{
    set(new_sequence_length, new_input_dimension, new_output_dimension, new_activation_function, new_name);
}


Index Dense3d::get_sequence_length() const
{
    return sequence_length;
}


Index Dense3d::get_input_dimension() const
{
    return weights.dimension(0);
}


void Dense3d::set_dropout_rate(const type& new_dropout_rate)
{
    dropout_rate = new_dropout_rate;
}


Index Dense3d::get_output_dimension() const
{
    return biases.size();
}


dimensions Dense3d::get_output_dimensions() const
{
    return { sequence_length, get_output_dimension() };
}


Index Dense3d::get_parameters_number() const
{
    return biases.size() + weights.size();
}


type Dense3d::get_dropout_rate() const
{
    return dropout_rate;
}


Tensor<type, 1> Dense3d::get_parameters() const
{
    Tensor<type, 1> parameters(weights.size() + biases.size());

    Index index = 0;

    copy_to_vector(parameters, weights, index);
    copy_to_vector(parameters, biases, index);

    return parameters;
}


const Dense3d::Activation& Dense3d::get_activation_function() const
{
    return activation_function;
}


string Dense3d::get_activation_function_string() const
{
    switch (activation_function)
    {
    case Activation::HyperbolicTangent: return "HyperbolicTangent";
    case Activation::Linear: return "Linear";
    case Activation::RectifiedLinear: return "RectifiedLinear";
    case Activation::Softmax: return "Softmax";
    default: return {};
    }
}


void Dense3d::set(const Index& new_sequence_length,
                  const Index& new_input_dimension,
                  const Index& new_output_dimension,
                  const Dense3d::Activation& new_activation_function,
                  const string& new_name)
{
    sequence_length = new_sequence_length;

    biases.resize(new_output_dimension);

    weights.resize(new_input_dimension, new_output_dimension);

    set_parameters_glorot();

    activation_function = new_activation_function;

    name = new_name;

    layer_type = Type::Dense3d;

    dropout_rate = 0;
}


void Dense3d::set_parameters(const Tensor<type, 1>& new_parameters, Index& index)
{
    copy_from_vector(weights, new_parameters, index);
    copy_from_vector(biases, new_parameters, index);
}


void Dense3d::set_activation_function(const Dense3d::Activation& new_activation_function)
{
    activation_function = new_activation_function;
}


void Dense3d::set_activation_function(const string& new_activation_function_name)
{
    if (new_activation_function_name == "HyperbolicTangent")
        activation_function = Activation::HyperbolicTangent;
    else if (new_activation_function_name == "Linear")
        activation_function = Activation::Linear;
    else if (new_activation_function_name == "RectifiedLinear")
        activation_function = Activation::RectifiedLinear;
    else if (new_activation_function_name == "Softmax")
        activation_function = Activation::Softmax;
    else
        throw runtime_error("Unknown activation function: " + new_activation_function_name + ".\n");
}


void Dense3d::set_parameters_constant(const type& value)
{
    biases.setConstant(value);
    weights.setConstant(value);
}


void Dense3d::set_parameters_random()
{
    set_random(biases);
    set_random(weights);
}


void Dense3d::set_parameters_glorot()
{
    biases.setZero();

    const type limit = sqrt(6 / type(get_input_dimension() + get_output_dimension()));

    set_random(weights, -limit, limit);
}


void Dense3d::calculate_combinations(const Tensor<type, 3>& inputs,
                                     Tensor<type, 3>& combinations) const
{
    combinations.device(*thread_pool_device) = inputs.contract(weights, axes(2,0))
        + biases.reshape(array<Index, 3>{1, 1, combinations.dimension(2)})
         .broadcast(array<Index, 3>{combinations.dimension(0), combinations.dimension(1), 1});

    //sum_matrices(thread_pool_device.get(), biases, combinations);
}


void Dense3d::calculate_activations(Tensor<type, 3>& activations, Tensor<type, 3>& activation_derivatives) const
{
    switch(activation_function)
    {
    case Activation::Linear: linear(activations, activation_derivatives); return;
    case Activation::HyperbolicTangent: hyperbolic_tangent(activations, activation_derivatives); return;
    case Activation::RectifiedLinear: rectified_linear(activations, activation_derivatives); return;
    case Activation::Logistic: logistic(activations, activation_derivatives); return;
    case Activation::Softmax: softmax(activations); return;
    default: return;
    }
}


void Dense3d::forward_propagate(const vector<pair<type*, dimensions>>& input_pairs,
                                unique_ptr<LayerForwardPropagation>& layer_forward_propagation,
                                const bool& is_training)
{
    const TensorMap<Tensor<type, 3>> inputs = tensor_map<3>(input_pairs[0]);

    Dense3dForwardPropagation* this_forward_propagation =
        static_cast<Dense3dForwardPropagation*>(layer_forward_propagation.get());

    Tensor<type, 3>& outputs = this_forward_propagation->outputs;

    calculate_combinations(inputs,
                           outputs);

    if(is_training && dropout_rate > type(0))
        dropout(outputs, dropout_rate);

    is_training
        ? calculate_activations(outputs, this_forward_propagation->activation_derivatives)
        : calculate_activations(outputs, empty_3);
}


void Dense3d::back_propagate(const vector<pair<type*, dimensions>>& input_pairs,
                             const vector<pair<type*, dimensions>>& delta_pairs,
                             unique_ptr<LayerForwardPropagation>& forward_propagation,
                             unique_ptr<LayerBackPropagation>& back_propagation) const
{
    const TensorMap<Tensor<type, 3>> inputs = tensor_map<3>(input_pairs[0]);

    if(delta_pairs.size() > 1)
        add_deltas(delta_pairs);

    TensorMap<Tensor<type, 3>> deltas = tensor_map<3>(delta_pairs[0]);

    // Forward propagation

    const Dense3dForwardPropagation* dense3d_layer_forward_propagation =
        static_cast<Dense3dForwardPropagation*>(forward_propagation.get());

    const Tensor<type, 3>& activation_derivatives = dense3d_layer_forward_propagation->activation_derivatives;

    // Back propagation

    Dense3dBackPropagation* dense3d_back_propagation =
        static_cast<Dense3dBackPropagation*>(back_propagation.get());

    Tensor<type, 1>& bias_deltas = dense3d_back_propagation->bias_deltas;
    Tensor<type, 2>& weight_deltas = dense3d_back_propagation->weight_deltas;

    Tensor<type, 3>& input_deltas = dense3d_back_propagation->input_deltas;

    deltas.device(*thread_pool_device) = deltas * activation_derivatives;

    bias_deltas.device(*thread_pool_device) = deltas.sum(array<Index, 2>({0,1}));

    weight_deltas.device(*thread_pool_device) = inputs.contract(deltas, axes(0,0,1,1));

    input_deltas.device(*thread_pool_device) = deltas.contract(weights, axes(2,1));
}


void Dense3d::insert_gradient(unique_ptr<LayerBackPropagation>& back_propagation,
                              Index& index,
                              Tensor<type, 1>& gradient) const
{
    Dense3dBackPropagation* dense3d_back_propagation =
        static_cast<Dense3dBackPropagation*>(back_propagation.get());

    copy_to_vector(gradient, dense3d_back_propagation->weight_deltas, index);
    copy_to_vector(gradient, dense3d_back_propagation->bias_deltas, index);
}


void Dense3d::from_XML(const XMLDocument& document)
{
    const XMLElement* dense2d_layer_element = document.FirstChildElement("Dense3d");

    if(!dense2d_layer_element)
        throw runtime_error("Dense3d element is nullptr.\n");

    const Index new_sequence_length = read_xml_index(dense2d_layer_element, "InputsNumber");
    const Index new_input_dimension = read_xml_index(dense2d_layer_element, "InputsDepth");
    const Index new_output_dimension = read_xml_index(dense2d_layer_element, "NeuronsNumber");

    set(new_sequence_length, new_input_dimension, new_output_dimension);

    set_name(read_xml_string(dense2d_layer_element, "Name"));
    set_activation_function(read_xml_string(dense2d_layer_element, "Activation"));

    Index index = 0;

    set_parameters(to_type_vector(read_xml_string(dense2d_layer_element, "Parameters"), " "), index);
}


void Dense3d::to_XML(XMLPrinter& printer) const
{
    printer.OpenElement("Dense3d");

    add_xml_element(printer, "Name", name);
    add_xml_element(printer, "InputsNumber", to_string(get_sequence_length()));
    add_xml_element(printer, "InputsDepth", to_string(get_input_dimension()));
    add_xml_element(printer, "NeuronsNumber", to_string(get_output_dimension()));
    add_xml_element(printer, "Activation", get_activation_function_string());
    add_xml_element(printer, "Parameters", tensor_to_string(get_parameters()));

    printer.CloseElement();
}


void Dense3dForwardPropagation::print() const
{
    cout << "Outputs:" << endl
         << outputs << endl
         << "Activation derivatives:" << endl
         << activation_derivatives << endl;
}


Dense3dForwardPropagation::Dense3dForwardPropagation(const Index& new_batch_size, Layer* new_layer)
    : LayerForwardPropagation()
{
    set(new_batch_size, new_layer);
}


pair<type*, dimensions> Dense3dForwardPropagation::get_outputs_pair() const
{
    Dense3d* perceptron_layer_3d = static_cast<Dense3d*>(layer);

    const Index sequence_length = perceptron_layer_3d->get_sequence_length();
    const Index output_dimension = perceptron_layer_3d->get_output_dimension();

    return { (type*)outputs.data(), { batch_size, sequence_length, output_dimension } };
}


void Dense3dForwardPropagation::set(const Index& new_batch_size, Layer* new_layer)
{
    layer = new_layer;

    Dense3d* perceptron_layer_3d = static_cast<Dense3d*>(layer);

    batch_size = new_batch_size;

    const Index output_dimension = perceptron_layer_3d->get_output_dimension();

    const Index sequence_length = perceptron_layer_3d->get_sequence_length();

    outputs.resize(batch_size, sequence_length, output_dimension);

    activation_derivatives.resize(batch_size, sequence_length, output_dimension);
}


void Dense3dBackPropagation::set(const Index& new_batch_size, Layer* new_layer)
{
    layer = new_layer;

    Dense3d* perceptron_layer_3d = static_cast<Dense3d*>(layer);

    batch_size = new_batch_size;

    const Index output_dimension = perceptron_layer_3d->get_output_dimension();
    const Index sequence_length = perceptron_layer_3d->get_sequence_length();
    const Index input_dimension = perceptron_layer_3d->get_input_dimension();

    bias_deltas.resize(output_dimension);
    weight_deltas.resize(input_dimension, output_dimension);
    input_deltas.resize(batch_size, sequence_length, input_dimension);
}


void Dense3dBackPropagation::print() const
{
    cout << "Biases derivatives:" << endl
         << bias_deltas << endl
         << "Synaptic weights derivatives:" << endl
         << weight_deltas << endl;
}


Dense3dBackPropagation::Dense3dBackPropagation(const Index& new_batch_size, Layer* new_layer)
    : LayerBackPropagation()
{
    set(new_batch_size, new_layer);
}


vector<pair<type*, dimensions>> Dense3dBackPropagation::get_input_derivative_pairs() const
{
    Dense3d* perceptron_layer_3d = static_cast<Dense3d*>(layer);

    const Index sequence_length = perceptron_layer_3d->get_sequence_length();
    const Index inputs_depth = perceptron_layer_3d->get_input_dimension();

    return {{(type*)(input_deltas.data()),
             {batch_size, sequence_length, inputs_depth}}};
}

}

// OpenNN: Open Neural Networks Library.
// Copyright(C) 2005-2025 Artificial Intelligence Techniques, SL.
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
